---
name: software-engineering-documentation-guidelines
description: >
  Standards and guidelines for all written documentation at Elios Technology. Use this skill
  whenever writing, reviewing, creating, or updating ANY of the following: product specs,
  feature docs, architecture & design docs, API documentation, runbooks, README files
  (repo-level, story-level backend or frontend, spike), ADRs, post-incident reviews,
  inline code comments, or any Loop/wiki content. Trigger on any mention of: writing a
  spec, documenting a feature, creating a runbook, updating a README, writing an ADR,
  API docs, architecture doc, user story README, spike README, postmortem, inline comment,
  documentation review, doc structure, doc metadata, or "how do I document X".
---

# Software Engineering Documentation Guidelines

These are the enforced documentation standards for Elios Technology. Apply them whenever
creating or reviewing any written artifact — code comments, READMEs, specs, runbooks,
API docs, architecture docs, ADRs, spikes, or postmortems.

---

## 1. Universal Rules (apply to every doc type)

Every document — no exceptions — must include:

**Metadata header** at the top:
```
Title:
Doc ID / filename:
Status: Draft | In Review | Approved | Active | Deprecated | Archived
Author(s):
Owner: (one named person, not a team)
Engineering Owner:
QA Owner:
Ops Owner:
Created: YYYY-MM-DD
Last updated: YYYY-MM-DD
Related Epic / Ticket(s):
Short summary: (1 line, non-technical)
Contact:
```

**Executive summary / TL;DR** — 1–3 sentences at the top. Lead with the answer.
Non-technical readers must get the gist without scrolling.

**Change history section** at the bottom:
```
## Change History
- v1.0 – YYYY-MM-DD – Description (Author)
```

**Status lifecycle**: Draft → In Review → Approved → Active → Deprecated → Archived.
Never delete documents. Archive them.

---

## 2. Voice, Tone & Language

- Professional, direct, plain English. Avoid marketing fluff and jargon unless defined.
- **Active voice**: "The API returns 404." Not "A 404 is returned by the API."
- **Second person** ("you") for runbooks and how-tos.
- **Third person / neutral** ("the system", "the user") for specs and reference docs.
- Present tense for facts. Past tense for completed events.
- Spell out numbers one–nine; use numerals for 10+.
- Dates: `YYYY-MM-DD`, times in UTC. Always state timezone.
- Acronyms: spell out on first use — "OpenID Connect (OIDC)".
- Inclusive language: use "they", avoid "guys", replace "master/slave" with "primary/replica".
- Short sentences. No culture-specific idioms.

---

## 3. Formatting Rules

- Use Markdown. `#` H1 for page title only. `##` and `###` for sections.
- Fenced code blocks with language label: ` ```ts `, ` ```csharp `, ` ```json `.
- Inline code for identifiers, paths, filenames: `signup.email`, `app/src/Signup.tsx`.
- Bold for emphasis (owners, status). Italics sparingly.
- Tables for short structured metadata only — not for prose.
- Line length ~80–100 characters where possible.
- Lead with the most actionable items (status, owner, acceptance criteria, runbook steps).
- Break long docs into sections; link to deep artifacts rather than embedding everything.

---

## 4. Acceptance Criteria Standard

Always write testable acceptance criteria. Use **Given / When / Then** format or numbered bullets.

**Good:**
```
Given a valid email, When the user submits the signup form,
Then the API returns 201 and verificationSent: true.
```

**Bad:** "Signup should work and emails should be sent."

- Use concrete outcomes: "returns 201" not "should return success".
- Include environment and test data requirements if relevant.

---

## 5. Document Types — Minimum Required Content

### 5a. Repository README
- Non-technical 1–2 line summary + owner + contacts
- Prereqs (OS, tooling, Node/.NET versions)
- Quick start: clone → build → run (copy-paste commands)
- Env variables & secrets pointers (no actual secrets)
- OCI tenancy/compartment/key resources (where applicable)
- Links to architecture doc, runbooks, API docs, related repos
- Status (active / maintenance / archived)

### 5b. Story-level README — Backend (.NET)
Required sections (in order):
TL;DR → Owners & Contacts → Acceptance Criteria → Definition of Done →
Background & Purpose → Scope & Non-Goals → API Contract & Examples →
Architecture & Design → Local Development → Configuration & Secrets →
Auth & Authorization → Data & Migrations → Observability →
Health Checks → CI/CD → Deployment & Rollback → Security & Compliance →
Troubleshooting & Runbook → Tests & Quality Gates → Changelog

- Must include copy-paste `dotnet` commands.
- Must include EF Core migration commands if DB changes are involved.
- Kubernetes probe examples for health checks.
- Pact contract test references if consuming or providing an API.

### 5c. Story-level README — Frontend (React/TS)
Required sections (in order):
TL;DR → Background → Acceptance Criteria → Scope & Non-Goals →
Design & UX (Figma link) → Implementation Notes → Repro / Local Dev →
Tests → CI & Pipeline → Observability & Metrics → Security & Privacy →
Deployment & Rollout → Artifacts & Links → Owner & Contacts → PR Checklist

- Must include copy-paste `npm`/`pnpm` commands.
- Must include `tsc --noEmit` and `eslint` gates.
- Accessibility: jest-axe + cypress-axe required for UI stories.
- Feature flag name and rollout plan required.

### 5d. Spike / Research README
Required:
- Status, author, date, ticket, outcome type, stakeholders
- TL;DR with clear recommendation
- Goals / Acceptance Criteria (measurable questions)
- Approach + reproducibility (exact commands)
- Findings with concrete numbers (p50/p95/p99, cost estimates, error rates)
- Risks & tradeoffs
- **Explicit decision**: Adopt / Prototype / Reject / Defer + rationale
- Artifacts with paths/links
- Owner + next steps with owners and due dates

### 5e. Architecture & Design Doc
Required sections:
- Elevator summary (1–2 lines, non-technical)
- Context & Problem Statement
- Goals & Non-Goals
- **High-level diagram** (one image scannable in ≤10s) — link to editable source (draw.io/Mermaid/Figma)
- Component descriptions & responsibilities
- Data flow & sequence
- Deployment pattern & OCI mapping (tenancy, compartment, OKE cluster, storage, IAM, Terraform)
- Scaling, resilience & availability
- Security & compliance (encryption, KMS, data residency, audit)
- Monitoring, SLOs & runbook links
- Cost considerations
- **Alternatives considered & trade-offs**
- Migration / rollout plan
- Open questions & risks (with owners + target dates)
- ADR links for every major decision

OCI-specific — always record:
- Tenancy & compartment names
- OKE cluster / service names
- Network layout (VCN, subnets)
- IAM policies
- Storage buckets + lifecycle rules
- Terraform module & state location

### 5f. API Documentation
Required:
- Base URLs & environments (sandbox, staging, prod)
- Auth scheme (OAuth2, JWT, API key) with token format + refresh flows
- Endpoints: path, method, full request/response JSON examples, field types
- Error response schema, status codes, retry semantics
- Rate limits and behaviour on limit breach
- Idempotency key support
- Versioning & deprecation policy (90-day minimum notice for public APIs)
- `curl`, TypeScript `fetch`, and C# `HttpClient` examples
- Link to `openapi.yaml` (repo: `/api/openapi.yaml`)
- Changelog of breaking / non-breaking changes

### 5g. Runbooks (Setup / Deploy / Incident)
Required metadata: Title, Summary, Owner, Environment, Created, Last updated, Status, Contact/On-call, Related links.

Required sections:
- Purpose & scope
- Preconditions & required access (OCI compartments, IAM roles, CLI tools)
- Step-by-step procedures with **exact copy-paste commands** (deploy, validate, rollback, scale)
- Expected output snippets for each command
- Common failure modes & troubleshooting (logs to check, diagnostic queries)
- Verification & validation (exact curl/query + expected response)
- Escalation & contacts (sequence: on-call → eng lead → security)
- Post-incident update procedure
- Rollback decision criteria

OCI-specific: tenancy, compartment, OKE cluster name, namespace, Terraform state location, IAM roles required.

**Never** embed secrets. Use placeholders: `<OCI_VAULT_SECRET>`.

### 5h. Product Spec / Feature Doc
Required sections:
- Metadata (Title, Doc ID, Status, Author, Eng Owner, QA Owner, Ops Owner, Epic, dates)
- Executive summary (1–3 sentences, KPIs targeted)
- Problem statement & objectives (measurable success metrics)
- Users & personas
- Proposed solution (user flow, mockup links, architecture diagram)
- Scope & out of scope
- **Acceptance criteria** (Given/When/Then, numbered, testable)
- API / integration contracts (request/response JSON, auth, error codes)
- Data model / DB changes (migrations, retention, PII notes)
- Non-functional requirements (concrete numbers: latency < Xms, availability %, RPS)
- Testing approach (unit, integration, E2E, load test thresholds)
- Deployment & rollout plan (feature flags, canary %, rollback steps)
- Ops & runbook summary
- Observability & analytics (event names, dashboards, SLO targets)
- Privacy, legal & compliance
- Dependencies & risks (top 3 + mitigations)
- Change history

### 5i. ADR (Architectural Decision Record)
Minimum fields:
```
Title:
Date: YYYY-MM-DD
Status: Proposed | Accepted | Deprecated
Context:
Decision:
Consequences:
Alternatives considered:
Owner:
Link to implementation:
```
Use ADRs for any decision affecting architecture, cost, compliance, scale, or cross-team work.

### 5j. Post-Incident Review (PIR)
Required:
- Incident summary with UTC timeline
- Impact (users, environments, transactions)
- Root cause & contributing factors
- Actions taken & resolution steps
- Short-term fixes + long-term remediation (owner per item)
- Lessons learned & monitoring changes
- Links to runbooks, alerts, dashboards

### 5k. Inline Code Comments
**When to comment**: non-obvious logic, workarounds, business rules, compliance requirements, TODOs, OCI/platform quirks.

**What to include**: why the code exists, assumptions, link to ticket/ADR.

**Never**: restate obvious code, include secrets/PII, write long essays (link to ADR instead).

Formats:
```ts
// Why: <one-line reason>. See: <ADR-ID or ticket>.

/**
 * <One-line summary>
 * Why: <short reason>
 * See: <ADR-ID> | <KB link> | <ticket>
 * @param name - description
 * @returns description
 */

// TODO [owner|PROJ-123]: <short actionable message> (target: YYYY-MM-DD)
```

C# XML:
```csharp
/// <summary>One-line summary.</summary>
/// <remarks>Why: <short reason>. See ADR-2025-xx.</remarks>
/// <param name="id">...</param>
/// <returns>...</returns>
```

---

## 6. Code Examples in Docs

- Realistic but minimal. Short and copy-paste ready.
- **Never** include real credentials, keys, or private URLs. Use `{{OCI_VAULT_SECRET}}`.
- Label language on every fenced block.
- JSON: camelCase fields consistent with APIs.

Good:
```json
{
  "email": "user@example.com",
  "sendVerification": true
}
```

---

## 7. Diagrams

- Prefer editable diagrams (Mermaid, draw.io, Figma). Link canonical source files.
- Store exports (SVG/PNG) in `/docs/diagrams/<project>/`.
- Always include alt text and short caption.
- Architecture diagrams must annotate: services, queues, DB, OCI resources.

---

## 8. File Naming

- Product specs: `project-feature-shortdesc-v{MAJOR}.{MINOR}.md`
- Runbooks: `runbook-<service>-<purpose>-<env>.md`
- Architecture docs: `arch-<project>-<shortname>.md`
- API docs (KB): `api-<service>-v<major>.md`
- OpenAPI spec: `/api/openapi.yaml` (repo root, canonical)

---

## 9. Storage & Canonical Locations

| Doc Type | Canonical | Mirror |
|---|---|---|
| Product specs | Loop → Product Specs | `docs/product-specs/` in repo |
| Architecture docs | Loop → Architecture | `/docs/architecture/` in repo + diagram source |
| API docs (OpenAPI) | Repo `/api/openapi.yaml` | Human-readable page in Loop |
| Repo README | `README.md` (repo root) | — |
| Runbooks | Loop → General → Runbooks | `docs/runbooks/` in repo |
| Postmortems | Loop → General → Postmortems | Link from incident ticket |
| ADRs | Loop → Architecture | `/docs/adr/` in repo |

Canonical in Loop wins if mirror differs. Update mirror immediately.

---

## 10. Ownership & Review

- **Owner** = one named person. Not a team.
- Every doc requires minimum reviewers before `Approved`: Engineering Owner (technical correctness), QA Owner (testability), Product Owner (business correctness). Add Security/Compliance if PII or regulated data is involved.
- Review cadence: quarterly for active products; annually for low-activity.
- If outdated and you are **not** the owner: tag the owner in Loop. If unresponsive after 5 business days, escalate to PM/CTO for reassignment.
- **Never rewrite whole docs**. Make small incremental updates with changelog entries.

---

## 11. Security & Privacy

- Never include credentials, private keys, or PII.
- Screenshots with PII must be redacted before publishing.
- Tag security-sensitive docs in metadata: `security-sensitive`.
- Sensitive operational commands: store in restricted repo section, reference from Loop with access instructions.

---

## 12. Pre-Publish Checklist (every doc)

Before marking any document `Approved` or `Published`:

- [ ] Metadata present (owner, status, dates, contact)
- [ ] 1–2 line non-technical summary present
- [ ] Executive summary / TL;DR at the top
- [ ] Acceptance criteria are testable and numbered (specs)
- [ ] Reproducible run/deploy commands included and tested (READMEs, runbooks)
- [ ] Diagrams or links to diagrams included
- [ ] Links to tickets, repos, API specs, dashboards present
- [ ] Sensitive info removed / redacted
- [ ] Cross-functional reviewer assigned and comments resolved
- [ ] Change history updated
- [ ] Canonical location set and mirror linked (if applicable)

---

## 13. Non-Technical Summary Requirement

Every doc must include a "What this means for" line for relevant non-technical roles:

- **Sales / BizDev**: what can be demoed, what SLAs can be committed to.
- **Ops**: what to check daily, on-call responsibilities, escalation path.
- **Customers**: expected downtime, capacity, user-facing impact.

Example:
```
"What this means for Ops: check OCI object storage usage daily; alert at 80%."
"What this means for Sales: demoable in sandbox; SSO setup takes 10 minutes."
```
